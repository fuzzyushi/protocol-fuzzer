/* $OpenBSD: version.h,v 1.78 2016/12/19 04:55:51 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.4"
