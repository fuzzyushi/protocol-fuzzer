/* $OpenBSD: version.h,v 1.79 2017/03/20 01:18:59 djm Exp $ */

#define SSH_VERSION	"OpenSSH_7.5"
